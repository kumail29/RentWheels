How to run Project
1. Download and Unzip the file on your local system copy rentwheels .
2. Put rentwheels folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database rentwheels
Import database rentwheels.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/rentwheels”
Login Details for user:
Username : test@gmail.com
Password: Test@123

For Admin Panel
Open Your browser put inside browser “http://localhost/rentwheels/admin”
Login Details for admin :
Username: admin
Password: Test@12345